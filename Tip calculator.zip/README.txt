# Tip Calculator

## Overview

A simple command-line application that calculates tip based on the bill amount.

## Features

- Input bill amount and tip percentage to calculate the tip.

## Technologies Used

- C#

## How to Run

1. Compile the program: `csc TipCalculator.cs`

2. Run the program: `TipCalculator`